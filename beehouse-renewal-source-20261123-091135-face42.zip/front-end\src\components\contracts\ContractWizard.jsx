import TenantPicker from '../tenants/TenantPicker'
import { useState } from 'react'
import ContractForm from '../forms/ContractForm'
import DateInput from '../ui/DateInput'
import { formatDateForApi, formatDateForDisplay, isValidDisplayDate } from '../../utils/date'
import { formatCurrency, formatUtilityValue } from '../../utils/formatters'
import ContractDraftServicesEditor from './ContractDraftServicesEditor'
import { editableContractService, contractServicesPayload, contractServicePricingError } from '../../utils/contractServices'
import { createBed, getContractContext } from '../../api/contractApi'
import { getApiErrorMessage, getApiFieldErrors } from '../../api/getApiErrorMessage'
import { openingDateFromContract, selectedUnitOpenings } from './contractOpeningRules.mjs'
import { Check, AlertCircle, FileText, ShieldCheck } from 'lucide-react'

const inputClass = 'mt-1 min-h-11 w-full min-w-0 rounded-lg border border-slate-300 px-3 py-2'
const buttonClass = 'min-h-11 rounded-lg bg-slate-900 px-4 py-2 text-sm text-white disabled:opacity-50'

export default function ContractWizard({ context, initial, onSubmit, allowActivation = true }) {
  const [step, setStep] = useState(0)
  const [core, setCore] = useState(() => initial ?? { monthly_rent: context.room.monthly_rent ?? '', deposit_amount: '', status: 'DRAFT' })
  const [people, setPeople] = useState(() => (initial?.occupant_tenant_ids ?? []).map(String))
  const [serviceOptions, setServiceOptions] = useState(context.services)
  const [services, setServices] = useState(() => (initial ? initial.agreed_services ?? [] : context.services).map(editableContractService))
  const [openings, setOpenings] = useState(() => {
    const saved = new Map((initial?.utility_openings ?? []).map(row => [Number(row.utility_meter_id), row]))
    return (context.utility_openings ?? []).map(opening => {
      const previous = saved.get(Number(opening.utility_meter_id))
      return { ...opening, ...(previous ?? {}), opening_reading: previous ? previous.opening_reading : '', reading_date: formatDateForDisplay(initial?.start_date ?? '') }
    })
  })
  const [representative, setRepresentative] = useState(() => String(initial?.lessor_representative_user_id ?? ''))
  const [paymentDueDay, setPaymentDueDay] = useState(() => initial ? initial.payment_due_day ?? '' : context.room.boarding_house.default_payment_due_day ?? '')
  const eligibleOpenings = selectedUnitOpenings(services, serviceOptions, openings)
  const openingDate = core.start_date ? formatDateForDisplay(core.start_date) : ''
  const demoOnly = context.demo_contracts_only === true
  const templateKey = type => `${type === 'DORM_BED' ? 'DORM_BED' : 'ROOM_RENTAL'}_${demoOnly ? 'DEMO' : 'STANDARD'}`
  const canActivate = allowActivation && !demoOnly && !initial?.is_demo
  const [templateId, setTemplateId] = useState(() => String(initial ? initial.contract_template_id ?? '' : (demoOnly ? context.templates?.find(template => template.template_key === templateKey('ROOM_RENTAL'))?.id : context.templates?.[0]?.id) ?? ''))
  const [contractType, setContractType] = useState(() => initial?.contract_type ?? 'ROOM_RENTAL')
  const [bedId, setBedId] = useState(() => String(initial?.bed_id ?? ''))
  const [beds, setBeds] = useState(() => context.beds ?? [])
  const [newBedCode, setNewBedCode] = useState('')
  const [newBedFloor, setNewBedFloor] = useState('')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [fieldErrors, setFieldErrors] = useState({})
  const errorFor = field => fieldErrors[field] && <p className="mt-1 text-sm text-red-700">{fieldErrors[field]}</p>
  const templateOptions = [...(context.templates ?? [])]
  if (initial?.contract_template && !templateOptions.some(template => String(template.id) === String(initial.contract_template_id))) templateOptions.push(initial.contract_template)
  const validateStep = current => {
    const errors = {}
    if (current === 1) {
      eligibleOpenings.forEach((opening, index) => {
        if (String(opening.opening_reading ?? '').trim() === '' || !Number.isFinite(Number(opening.opening_reading)) || Number(opening.opening_reading) < 0) errors[`utility_openings.${index}.opening_reading`] = 'Vui lòng nhập chỉ số đầu là số không âm.'
        if (!isValidDisplayDate(openingDate)) errors[`utility_openings.${index}.reading_date`] = 'Vui lòng nhập ngày bắt đầu hợp đồng ở Bước 1.'
      })
      const pricingError = services.map(contractServicePricingError).find(Boolean)
      if (pricingError) errors.services = pricingError
    }
    if (current === 2 && paymentDueDay !== '' && (!Number.isInteger(Number(paymentDueDay)) || Number(paymentDueDay) < 1 || Number(paymentDueDay) > 31)) errors.payment_due_day = 'Ngày thanh toán hàng tháng phải là số nguyên từ 1 đến 31.'
    setFieldErrors(errors)
    setError(Object.keys(errors).length ? 'Vui lòng kiểm tra các trường được đánh dấu.' : '')
    return Object.keys(errors).length === 0
  }
  const save = async status => {
    setError(''); setFieldErrors({})
    if (!validateStep(1)) { setStep(1); return }
    if (!validateStep(2)) { setStep(2); return }
    if (status === 'ACTIVE' && (!core.start_date || core.monthly_rent == null || !representative)) {
      setError('Để kích hoạt, vui lòng bổ sung ngày bắt đầu, giá thuê thỏa thuận và người đại diện Bên A.'); return
    }
    if (status === 'ACTIVE' && contractType === 'DORM_BED' && !bedId) {
      setFieldErrors({ bed_id: 'Vui lòng chọn giường cho hợp đồng ký túc xá.' }); return
    }
    if (paymentDueDay !== '' && (!Number.isInteger(Number(paymentDueDay)) || Number(paymentDueDay) < 1 || Number(paymentDueDay) > 31)) {
      setFieldErrors({ payment_due_day: 'Ngày thanh toán hàng tháng phải là số nguyên từ 1 đến 31.' })
      setError('Vui lòng kiểm tra ngày thanh toán hàng tháng.'); return
    }
    if (eligibleOpenings.some(opening => !isValidDisplayDate(openingDate) || opening.opening_reading === '' || !Number.isFinite(Number(opening.opening_reading)) || Number(opening.opening_reading) < 0)) {
      setError('Vui lòng kiểm tra chỉ số đầu không âm và ngày ghi theo dd/mm/yyyy.'); return
    }
    const pricingError = services.map(contractServicePricingError).find(Boolean)
    if (pricingError) { setError(pricingError); return }
    setSaving(true)
    try {
      const contractValues = { ...core }
      delete contractValues.auto_code
      // Older API records can still contain the retired invoice issue range.
      delete contractValues.invoice_issue_day_from
      delete contractValues.invoice_issue_day_to
      await onSubmit({ ...contractValues, status, contract_type: contractType, bed_id: contractType === 'DORM_BED' ? Number(bedId) : null, lessor_representative_user_id: representative ? Number(representative) : null,
        payment_due_day: paymentDueDay === '' ? null : Number(paymentDueDay),
        contract_template_id: templateId ? Number(templateId) : null,
        occupant_tenant_ids: people.filter(id => Number(id) !== Number(core.tenant_id)).map(Number), services: contractServicesPayload(services),
        utility_openings: eligibleOpenings.map(opening => ({ service_id: Number(opening.service_id), utility_meter_id: opening.utility_meter_id ? Number(opening.utility_meter_id) : null, opening_reading: Number(opening.opening_reading), reading_date: openingDateFromContract(core.start_date) })),
      })
    } catch (requestError) { setError(getApiErrorMessage(requestError)); setFieldErrors(getApiFieldErrors(requestError)) } finally { setSaving(false) }
  }
  const titles = ['Thông tin & tài chính', 'Người ở & dịch vụ', 'Đại diện & lịch thanh toán', 'Kiểm tra và lưu']
  const descriptions = ['Chọn mẫu và người đứng tên, sau đó ghi nhận các khoản đã thỏa thuận.', 'Kiểm tra người ở cùng, dịch vụ và chỉ số tại thời điểm bàn giao.', 'Xác định người đại diện và ngày thanh toán phù hợp với thỏa thuận.', 'Rà soát thông tin trước khi lưu. Bản nháp chưa phải hợp đồng có hiệu lực.']
  return <div className="contract-wizard min-w-0 space-y-4" aria-busy={saving}>
    <ol aria-label="Các bước tạo hợp đồng" className="bh-stepper">{titles.map((title, index) => <li key={title} aria-current={step === index ? 'step' : undefined} data-state={step === index && error ? 'error' : step === index ? 'current' : index < step ? 'complete' : 'upcoming'}><span className="bh-step-number" aria-hidden="true">{step === index && error ? <AlertCircle size={17} /> : index < step ? <Check size={17} /> : String(index + 1).padStart(2, '0')}</span><span><small>{step === index && error ? 'Cần kiểm tra' : index < step ? 'Đã đi qua' : step === index ? 'Đang thực hiện' : 'Tiếp theo'}</small>{title}</span></li>)}</ol>
    <div className="bh-contract-context"><span className="bh-context-icon"><FileText size={22} aria-hidden="true" /></span><div><strong>Phòng {context.room.room_code}</strong><p>{context.room.boarding_house.name}</p></div><span className="bh-type-label">{demoOnly || initial?.is_demo ? 'HỢP ĐỒNG DEMO' : 'BẢN NHÁP HỢP ĐỒNG'}</span></div>
    <div className="bh-step-intro"><p className="bh-eyebrow">BƯỚC {String(step + 1).padStart(2, '0')} / 04</p><h3>{titles[step]}</h3><p>{descriptions[step]}</p></div>
    <p className="bh-wizard-note"><ShieldCheck size={17} aria-hidden="true" />{demoOnly ? 'Chế độ DEMO: dùng hai mẫu minh họa theo quyền tài khoản; chỉ lưu nháp và in/PDF, không kích hoạt hoặc ghi nhận khoản thu.' : 'Bản nháp có thể chưa có giá thuê hoặc ngày bắt đầu. Dữ liệu thỏa thuận được chốt khi kích hoạt.'}</p>
    {step === 0 && contractType === 'DORM_BED' && <div className="grid gap-2 rounded-xl bg-white p-4 shadow-sm sm:grid-cols-[1fr_1fr_auto]">
      <input aria-label="Mã giường mới" value={newBedCode} onChange={event => setNewBedCode(event.target.value)} placeholder="Mã giường mới" className={inputClass} />
      <input aria-label="Tầng" value={newBedFloor} onChange={event => setNewBedFloor(event.target.value)} placeholder="Tầng (không bắt buộc)" className={inputClass} />
      <button type="button" disabled={!newBedCode.trim() || saving} onClick={async () => {
        setSaving(true); setError('')
        try {
          const response = await createBed(context.room.id, { bed_code: newBedCode.trim(), floor_label: newBedFloor.trim() || null })
          const bed = { id: response.data.data.id, bed_code: newBedCode.trim(), floor_label: newBedFloor.trim() || null }
          setBeds(previous => [...previous, bed]); setBedId(String(bed.id)); setNewBedCode(''); setNewBedFloor('')
        } catch (requestError) { setError(getApiErrorMessage(requestError)) } finally { setSaving(false) }
      }} className="mt-1 min-h-11 rounded-lg border px-3 disabled:opacity-50">Thêm giường</button>
    </div>}
    {step === 0 && <><div className="space-y-3 rounded-xl bg-white p-4 shadow-sm sm:p-6"><label htmlFor="contract-type" className="block text-sm font-medium">Loại hợp đồng</label><select id="contract-type" value={contractType} onChange={event => { const type = event.target.value; setContractType(type); setBedId(''); setTemplateId(String(context.templates.find(template => template.template_key === templateKey(type))?.id ?? '')) }} className={inputClass}><option value="ROOM_RENTAL">Thuê phòng</option><option value="DORM_BED">Thuê giường ký túc xá</option></select>{contractType === 'DORM_BED' && <><label htmlFor="contract-bed" className="block text-sm font-medium">Giường</label><select id="contract-bed" value={bedId} onChange={event => setBedId(event.target.value)} className={inputClass}><option value="">Chọn giường</option>{(beds).map(bed => <option key={bed.id} value={String(bed.id)}>{bed.floor_label ? `${bed.floor_label} · ` : ''}{bed.bed_code}</option>)}</select>{errorFor('bed_id')}{(beds).length === 0 && <p className="text-sm text-amber-700">Phòng chưa có giường. Hãy thêm giường tại đây trước khi lập hợp đồng.</p>}</>}<label htmlFor="contract-template" className="block text-sm font-medium">Mẫu hợp đồng</label><select id="contract-template" value={templateId} onChange={event => setTemplateId(event.target.value)} className={inputClass}><option value="">Chưa chọn — dùng mẫu đang hoạt động khi chốt</option>{templateOptions.filter(template => template.template_key === templateKey(contractType) || String(template.id) === templateId).map(template => <option key={template.id} value={String(template.id)} disabled={!template.is_active}>{template.name} — v{template.version}{template.is_active ? '' : ' (đã ngừng sử dụng)'}</option>)}</select>{errorFor('contract_template_id')}<p className="text-sm text-slate-500">{demoOnly ? 'Bản DEMO chỉ lưu nháp và in/PDF, không phải hợp đồng đầy đủ; không kích hoạt hoặc thay đổi người ở, phòng, hóa đơn.' : 'Mẫu được chốt khi kích hoạt hợp đồng.'}</p></div><ContractForm key="core" initialValues={core} contextRoomId={context.room.id} wizard onSubmit={async values => { setCore(values); setStep(1) }} submitLabel="Tiếp tục" /></>}
    {step === 1 && <div className="space-y-5 rounded-xl bg-white p-4 shadow-sm sm:p-6">
      <fieldset><legend className="font-semibold">Người ở cùng</legend><p className="my-2 text-sm text-slate-500">Người đứng tên được tự động thêm khi kích hoạt. Tối đa của phòng: {context.room.max_tenants ?? 'Chưa thiết lập'}.</p><TenantPicker label="Người ở cùng" multiple allowClear value={people.filter(id => Number(id) !== Number(core.tenant_id))} onChange={ids => setPeople(ids.map(String))} contextRoomId={context.room.id} excludeIds={core.tenant_id ? [Number(core.tenant_id)] : []} initialTenants={(initial?.occupants ?? []).map(person => person.tenant).filter(Boolean)} />{errorFor('occupant_tenant_ids')}</fieldset>
      <fieldset><legend className="mb-3 font-semibold">Dịch vụ áp dụng</legend><ContractDraftServicesEditor availableServices={serviceOptions} value={services} onChange={setServices} onSync={async () => { const response = await getContractContext(context.room.id); const available = response.data.data.services; setServiceOptions(available); setServices(available.map(editableContractService)); const latest = response.data.data.utility_openings ?? []; setOpenings(previous => { const saved = new Map(previous.map(row => [Number(row.service_id), row])); return [...latest.map(row => ({ ...row, opening_reading: saved.get(Number(row.service_id))?.opening_reading ?? '' })), ...previous.filter(row => !latest.some(item => Number(item.service_id) === Number(row.service_id))) ] }) }} />{errorFor('services')}{errorFor('service_ids')}</fieldset>
      <section className="space-y-3"><h3 className="font-semibold">Chỉ số đầu hợp đồng</h3>
        <p className="text-sm text-slate-600">Ngày bàn giao: <strong>{openingDate || 'Chưa chọn ở Bước 1'}</strong> (tự động lấy từ ngày bắt đầu thuê; muốn thay đổi hãy quay lại Bước 1).</p>
        <p className="text-sm text-slate-500">Chỉ nhập chỉ số thực tế cho dịch vụ điện/nước tính theo đơn vị (PER_UNIT) đã chọn. Không lấy chỉ số cuối tháng sau làm số ban đầu.</p>
        {eligibleOpenings.map((opening, index) => <div key={opening.service_id} className="space-y-2 rounded-lg border p-3"><strong className="text-sm">{opening.service_name} · {opening.unit}</strong><label className="block text-sm">Chỉ số tại ngày bắt đầu hợp đồng<input type="number" min="0" step="0.01" value={opening.opening_reading ?? ''} onChange={event => setOpenings(rows => { const found = rows.some(row => Number(row.service_id) === Number(opening.service_id)); return found ? rows.map(row => Number(row.service_id) === Number(opening.service_id) ? { ...row, opening_reading: event.target.value } : row) : [...rows, { ...opening, opening_reading: event.target.value }] })} className={inputClass} /></label>{errorFor(`utility_openings.${index}.opening_reading`)}{!opening.utility_meter_id && <p className="text-xs text-slate-500">Công tơ sẽ được đăng ký tự động khi lưu hợp đồng. Không cần thao tác thêm.</p>}</div>)}
        {eligibleOpenings.length === 0 && <p className="rounded bg-slate-50 p-3 text-sm">Không chọn dịch vụ điện/nước tính theo đơn vị, nên không cần nhập chỉ số đầu.</p>}
        {errorFor('utility_openings')}
      </section>
    </div>}
    {step === 2 && <div className="grid gap-5 rounded-xl bg-white p-4 shadow-sm sm:p-6 md:grid-cols-2"><div><label htmlFor="contract-representative" className="text-sm font-medium">Người đại diện Bên A (bắt buộc khi kích hoạt)</label><select id="contract-representative" value={representative} onChange={event => setRepresentative(event.target.value)} className={inputClass}><option value="">Chọn người đại diện</option>{context.representatives.map(person => <option key={person.user_id} value={String(person.user_id)}>{person.full_name} — {person.title}</option>)}</select>{errorFor('lessor_representative_user_id')}<p className="mt-2 text-sm text-slate-500">Chỉ gồm chủ trọ và quản lý đang được phân công. Không đồng nghĩa với chủ hộ pháp lý trong CT01.</p></div><div><label htmlFor="contract-payment-due-day" className="text-sm font-medium">Ngày thanh toán hàng tháng</label><input id="contract-payment-due-day" type="number" min="1" max="31" step="1" value={paymentDueDay} onChange={event => setPaymentDueDay(event.target.value)} className={inputClass} placeholder="1–31 (không bắt buộc)" aria-describedby="contract-payment-due-help" aria-invalid={Boolean(fieldErrors.payment_due_day)} />{errorFor('payment_due_day')}<p id="contract-payment-due-help" className="mt-2 text-sm text-slate-500">{paymentDueDay !== '' && Number.isInteger(Number(paymentDueDay)) && Number(paymentDueDay) >= 1 && Number(paymentDueDay) <= 31 ? `Hạn thanh toán của hóa đơn sẽ là ngày ${String(paymentDueDay).padStart(2, '0')} hàng tháng.` : 'Có thể để trống nếu chưa thỏa thuận ngày thanh toán.'} Nếu tháng không có ngày đã chọn, dùng ngày cuối cùng của tháng.</p><p className="mt-2 text-sm text-slate-500">Gợi ý từ cấu hình nhà trọ khi tạo mới; có thể thay đổi riêng cho hợp đồng này.</p></div></div>}
    {step === 3 && <section className="space-y-3 rounded-xl bg-white p-4 shadow-sm sm:p-6"><h3 className="font-semibold">Kiểm tra trước khi lưu</h3><dl className="grid gap-3 text-sm sm:grid-cols-2"><div><dt>Mã hợp đồng</dt><dd className="break-words font-medium">{core.contract_code || 'Tự động tạo khi lưu'}</dd></div><div><dt>Người đứng tên</dt><dd><TenantPicker readOnly value={core.tenant_id} onChange={() => {}} contextRoomId={context.room.id} /></dd></div><div><dt>Giá thuê thỏa thuận</dt><dd>{core.monthly_rent == null ? 'Chưa thiết lập' : formatCurrency(core.monthly_rent)}</dd></div><div><dt>Tiền cọc thỏa thuận (không phải đã thu)</dt><dd>{formatCurrency(core.deposit_amount)}</dd></div><div><dt>Người ở đăng ký</dt><dd>{1 + people.filter(id => Number(id) !== Number(core.tenant_id)).length}</dd></div><div><dt>Dịch vụ đã chọn</dt><dd>{services.length}</dd></div></dl><p className="rounded-lg bg-amber-50 p-3 text-sm text-amber-900">{demoOnly ? 'Bản DEMO chỉ lưu nháp và in/PDF; không kích hoạt, không đồng bộ người ở và không tạo hóa đơn hoặc thu tiền.' : 'Sau kích hoạt, các điều khoản cốt lõi, thông tin hai bên, dịch vụ và chỉ số đầu được chốt. Muốn thay đổi quan trọng cần hợp đồng mới. Chưa tạo hóa đơn ban đầu hay ghi nhận đã thu cọc.'}</p>{!allowActivation && !demoOnly && <p className="rounded-lg bg-blue-50 p-3 text-sm text-blue-900">Trước tiên hãy lưu bản nháp, sau đó ghi nhận tình trạng đồ vật trong biên bản bàn giao và xác nhận. Chỉ khi đó mới có thể chốt hợp đồng chính thức.</p>}<div className="flex flex-wrap gap-3"><button type="button" disabled={saving} onClick={() => save('DRAFT')} className="min-h-11 rounded-lg border px-4 py-2 text-sm disabled:opacity-50">{demoOnly || allowActivation ? 'Lưu nháp' : 'Lưu nháp để lập biên bản'}</button>{canActivate && <button type="button" disabled={saving} onClick={() => save('ACTIVE')} className={buttonClass}>{saving ? 'Đang lưu...' : 'Kích hoạt hợp đồng'}</button>}</div></section>}
    {error && <div role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700"><p>{error}</p>{Object.entries(fieldErrors).map(([key, value]) => <p key={key}>{value}</p>)}<p className="mt-2">Có thể quay lại các bước để chỉnh dữ liệu.</p></div>}
    <div className="flex flex-wrap gap-3">{step > 0 && <button type="button" disabled={saving} onClick={() => setStep(step - 1)} className="min-h-11 rounded-lg border px-4 py-2 text-sm">← Quay lại</button>}{step > 0 && step < 3 && <button type="button" onClick={() => { if (validateStep(step)) setStep(step + 1) }} className={buttonClass}>Tiếp tục</button>}</div>
  </div>
}
